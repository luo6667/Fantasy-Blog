export { default as About } from './about';
export { default as Blog } from './blog';
export { default as BlogDetail } from './blog-detail';
export { default as Home } from './home';
export { default as Plan } from './plan';
export { default as Resume } from './resume';
